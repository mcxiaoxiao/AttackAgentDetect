# Same-Challenge Retrieval — frozen source and result bundle

This archive contains the short paper, supplementary material, figures, frozen pair-level predictions, experiment protocols, source scripts, and point-estimate verifiers.

## Recheck the reported point estimates

From this directory, run:

```sh
python3 code/verify_shortpaper_tables.py --output results/recomputed_table_values.json
```

The table verifier uses only the Python standard library. It re-aggregates the included frozen pair predictions; it does not fit models. Its checks cover the five CTH action-bigram mixture shares, matched CTH XGBoost rates, both Agent-only XGBoost panels, the five-arm mechanism contrasts, each shuffled-seed point contrast, and the four XGBoost pair-support increments. A separate script recomputes the paired four-contrast max-T intervals from the included CTH predictions.

## Compile the PDFs

With Tectonic installed:

```sh
cd paper
tectonic --reruns 2 same-challenge-retrieval-shortpaper.tex
tectonic --reruns 2 same-challenge-retrieval-supplement.tex
```

The main paper includes references and must remain within eight pages. The supplement holds the complete measurement schema, full mixture metrics, threshold/no-match diagnostics, overlap sensitivity, mechanism controls, the exploratory pair-support analysis, source-specific tests, and CTH model-snapshot retrieval results.

## Scope of reproducibility

Pair-level files contain task labels, hashed trace IDs, scores, decisions, and thresholds; this archive excludes raw NYU transcripts, raw command strings, and raw event logs. The frozen outputs allow exact point-estimate re-aggregation without fitting. Re-running feature extraction and model fitting from source logs requires the upstream CTH/AIT source data, the pinned NYU repository revision, and the original experiment repository environment. The included `source/` scripts document those pipelines but cannot recreate excluded source-derived inputs by themselves.

The CTH label is same-task/challenge identity. It does not establish a common operator, Agent instance, attack, campaign, or real-world activity. CTH role composition is observational because collection interface and recorded role covary.
