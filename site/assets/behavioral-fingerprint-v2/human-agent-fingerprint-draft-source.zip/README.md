# Matched behavioral-fingerprint draft bundle

This bundle contains the standalone TeX manuscript and every figure/table input required to compile it. It also includes frozen pair predictions, manifests, aggregate analyses, verifiers, and the research notes needed to reproduce the reported summaries. Raw AIT logs and raw command text are not included. Upstream dataset terms remain applicable.

## Compile the manuscript

From the extracted bundle root:

```sh
cd research/paper
tectonic --reruns 2 human-agent-fingerprint-draft.tex
```

The manuscript uses the same 10 pt type and 0.72 in margins as the prior paper. The main text and references end on page 6; the complete PDF has 11 pages, with appendices following.

## Recompute summary tables and figures

The frozen v1 pair predictions and the v2 five-share and NYU predictions are included. From the extracted bundle root, install the versions recorded in `research/results/matched_fingerprint_v1/environment.json` and run:

```sh
.venv/bin/python research/experiments/matched_fingerprint_v2/analyze_cth_five_share.py
.venv/bin/python research/experiments/matched_fingerprint_v2/build_unified_bst_ablation.py
.venv/bin/python research/experiments/matched_fingerprint_v2/analyze_independent_nyu_agent.py
.venv/bin/python research/experiments/matched_fingerprint_v2/build_paper_results.py
```

The final command regenerates the TeX tables and figures. In the full repository it also updates the research-page results section; page layout and dependencies remain in the repository. The public-source NYU task manifest and frozen protocol are included. NYU is a one-shot confirmation set and must not be used to select a different model, threshold, representation, or subgroup.

## Evidence scope

Same-task and same-challenge labels are retrieval proxies. They do not verify shared attack activity, campaign, operator, or Agent instance. The external NYU evaluation is Agent--Agent only; independent Human--Agent confirmation remains unavailable. See `research/reports/matched-fingerprint-v2.md` for the bounded results and negative findings.
